	This release contains the posterior and a short example, written in Python, on how to load and use the posterior. We emphasize that our analysis and hence these posteriors are constructed with the assumption that the astrophysical population produces neutrinos with an E^(-2) energy spectrum.

##########################################
# Data archive description: posterior.h5 #
##########################################

	Within this HDF5 formatted file, five tables named Isotropic, Galactic_disk, Fermi_bubble, SFD_dust, and Northern_sky contain the posterior samples for their respective templates. 

	Each table describes equally weighted samples using five columns. Four columns, labeled ln_A, ln_Fb, n1, and n2, contain the coordinates for the sample in natural logarithmic parameter space for the differential source-count function normalization A and break F_b, while the power indices n_1 and n_2 are in linear space. The fifth column — labeled loglikelihood — gives the natural logarithm of the likelihood function at the location of the corresponding sample. In addition, each table has two attributes named P_log_evidence and NP_log_evidence that contain the natural logarithm of the evidence integral for the Poissonian model and non-Poissonian model, respectively. 

	The root node of the HDF5 file also contains a series of attributes named units_ln_A, units_ln_Fb, units_n1, and units_n2 that specify the units that the posterior sample coordinates are given in. Another series of root attributes named prior_ln_A, prior_ln_Fb, prior_n1, and prior_n2 give the probability density of the uniform priors for each of the model parameters.
	
	
###########################################
# Example program description: example.py #
###########################################

	An example program that loads the posterior samples, computes the Bayes factor at specific model locations in parameter space, and generates a reproduction of Figure 10 in the accompanying paper. 
	
	This program has been tested with the following versions of python:
		Python 2.7.16
		Python 3.7.4
	
	It following python packages:
		numpy, 
		scipy,
		pytables (named tables in pip)
		
	In addition, matplotlib is required to generate the reproduction of Figure. 10
	
	